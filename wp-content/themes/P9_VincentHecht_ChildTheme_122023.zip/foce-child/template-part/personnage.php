<?php ?>
<article id="characters">
        <h3>Les personnages</h3>
        <div class="swiper">
                <div class="swiper-wrapper">
                        <div class="swiper-slide">
                                <img src="<?php echo get_stylesheet_directory_uri() . '/assets/personnage/Kawaneko.png'; ?>" alt="chat bleu tacheté de blanc">
                                <p>Kawaneko</p>
                        </div>
                        <div class="swiper-slide">
                                <img src="<?php echo get_stylesheet_directory_uri() . '/assets/personnage/Orenjiiro.png'; ?>" alt="chat orange au yeux vert">
                                <p>Orenjiiro</p>
                        </div>
                        <div class="swiper-slide">
                                <img src="<?php echo get_stylesheet_directory_uri() . '/assets/personnage/Pinku.png'; ?>" alt="chat blanc au yeux bleu">
                                <p>Pinku</p>
                        </div>
                        <div class="swiper-slide">
                                <img src="<?php echo get_stylesheet_directory_uri() . '/assets/personnage/Tenshi.png'; ?>" alt="chat jaune au yeux rose">
                                <p>Tenshi</p>
                        </div>
                        <div class="swiper-slide">
                                <img src="<?php echo get_stylesheet_directory_uri() . '/assets/personnage/Jaakuna.png'; ?>" alt="chat noir au yeux vert">
                                <p>Jaakuna</p>
                        </div>
                </div>       
        </div>

</article>